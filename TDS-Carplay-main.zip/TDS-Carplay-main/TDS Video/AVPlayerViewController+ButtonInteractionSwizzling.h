//
//  AVPlayerViewController+ButtonInteractionSwizzling.h
//  TDS Video
//
//  Created by Thomas Dye on 06/08/2024.
//

#ifndef AVPlayerViewController_ButtonInteractionSwizzling_h
#define AVPlayerViewController_ButtonInteractionSwizzling_h
#import <AVKit/AVKit.h>

@interface AVPlayerViewController (ButtonInteractionSwizzling)

@end

#endif /* AVPlayerViewController_ButtonInteractionSwizzling_h */
