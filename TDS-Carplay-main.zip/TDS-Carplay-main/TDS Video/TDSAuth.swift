//
//  TDSAuth.swift
//  TDS Video
//
//  Created by Thomas Dye on 21/03/2025.
//

//var auth = Auth<login>(Config: Auth_Config(APNS:true,
//                                           BundleID: "net.thomasdye.TDS-Video",AccountType: "TDS",
//                                             TokenSuiteName: "group.net.thomasdye.Auth_Creds", RequireFaceID: false,
//                                           LoginViewconfig: LoginViewConfigops(
//                                            Title: "TDS CarPlay Video",
//                                            Username: false, Password: false,
//                                            Canlogin: false, signinwithApple: false,SignUP: false,
//                                            Nologin_message: "Server error",LoginButtonColour: UIColor(red: 0.2, green: 0.7, blue: 1, alpha: 1),
//                                            LoginImage_name: "TDSCCTV 2",
//                                            TDS_Login_explain_text:true
//                                           ),
//                                        
//                                            UNAuthorizationOptions: [.alert,.badge,.carPlay,.sound]
//
//                                          ))
