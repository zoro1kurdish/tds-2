# TDS-CarPlay

![Downloads](https://api.thomasdye.net/app/ThomasRandom/TDSVideo/AmountOfDownloads)

# This app is not meant to be used while driving 

## What is this 

TDS CarPlay is an app that allows you to view videos and show your screen on your carpay screen, allowing for watching movies and other things while in your car


## Download 

Test flight Beta link download link - [TDS CarPlay](https://testflight.apple.com/join/6drWGVde) 
The beta is now full - i will leave the link here in case people leave it, 
To stay up to date with info and when I come out with a new beta, subscribe to the news letter [news letter](https://news.thomasdye.net/)  

## Links 

Youtube Video tutorial - https://youtu.be/gI3Tj2KP290 




Any issues please reach out. 


## Wheres the code?

I am pleased to say the code has now been added for you all to use, see bellow about use. 





## Install

To install this


1. Download the code 


2. Change the bundle IDS 


3. Build and run the code 


4. Enjoy the ability to watch videos in your car  


## Feature request / Bugs 

Please make issues here and tell me about what you'd like in the app or your problem and I will work on them as soon as I can. 


## Support 

If you are liking the app it would really help if you'd buy me a coffee and support the feature development of the app and other things do.
Buy me a coffee - https://buymeacoffee.com/Thomadye

I would like to say a massive thank you to everyone who has downloaded my app, its way more popular then i ever thought it would be!

If you are interested in updates please follow on one of the two bellow - I post updates there about what i am doing building and stuff all tech related.
 
https://www.youtube.com/channel/UCn8DxUf388I1B7Lxzqv5KRw
http://instagram.com/thomas_dye





## Use of My App and Code

I’m happy for anyone to use my app and code for **personal, non-commercial** use.

**You are not permitted to sell, redistribute, or use this app or its code for commercial purposes** (i.e. to make money) without my explicit permission.

If you would like to use this project in a commercial setting, please [contact me](mailto:apple@thomasdye.net) to discuss licensing terms.

